%% PLotten der Gasphasen daten 
clf
cla
Velocity_Data_Gas = readtable('/home/mwi/Documents/bwSyncShare/bwSync/Documents/00_Publikationen/Review of Scientific Instruments/Daten/MC_MWi_DryChannel_RH85_T25Deg_CopperPlate_Smooth_11_2024/06_11_2024_Without_Honeycomb/Labview Data/Auswertung_Gasgeschwindigkeit/Overview_06_11_2024_DryChannel_Without_Honeycomb.xlsx');
% Plot velocities including the measurement uncertainty of the Kalibarion
errors = 0.2*ones(size(Velocity_Data_Gas,1));
% Data sheet
figure(1); 
%v1=plot(Velocity_Data_Gas, "Z_mm_", "ReG4900","Color",[0 0.4470 0.7410],"Marker","square","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0 0.4470 0.7410]);
%hold on
errorbar(Velocity_Data_Gas.Z_mm_,Velocity_Data_Gas.ReG4900, Velocity_Data_Gas.UncertainitySVM,"Color",[0 0.4470 0.7410],"Marker","square","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0 0.4470 0.7410]);
hold on
errorbar(Velocity_Data_Gas.Z_mm_,Velocity_Data_Gas.ReG8900, Velocity_Data_Gas.UncertainitySVM,"Color",[0.8500 0.3250 0.0980],"Marker","diamond","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0.8500 0.3250 0.0980]);
%plot(Velocity_Data_Gas, "Z_mm_", "ReG8900","Color",[0.8500 0.3250 0.0980],"Marker","diamond","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0.8500 0.3250 0.0980]);
hold on 
errorbar(Velocity_Data_Gas.Z_mm_,Velocity_Data_Gas.ReG12900, Velocity_Data_Gas.UncertainitySVM,"Color",[0.4940 0.1840 0.5560],"Marker","^","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0.4940 0.1840 0.5560]);

hold on
errorbar(Velocity_Data_Gas.Z_mm_,Velocity_Data_Gas.ReG16900, Velocity_Data_Gas.UncertainitySVM,"Color",[0.4660 0.6740 0.1880],"Marker","v","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0.4660 0.6740 0.1880]);

hold on 
errorbar(Velocity_Data_Gas.Z_mm_,Velocity_Data_Gas.ReG20900, Velocity_Data_Gas.UncertainitySVM,"Color",[0.6350 0.0780 0.1840],"Marker","o","LineStyle","none","MarkerSize",8,"MarkerFaceColor",[0.6350 0.0780 0.1840]);

lgd1=legend('$Re_{gas} = 4,900$', '$Re_{gas} = 8,900$', '$Re_{gas} = 12,900$', '$Re_{gas} = 16,900$', '$Re_{gas} = 20,900$', 'Interpreter', 'latex','FontSize',18,'Location','northoutside','Orientation','horizontal');
lgd1.Location= 'northoutside';
lgd1.Orientation= 'horizontal';
lgd1.NumColumns =3;

ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
ylim([0 10])
xlabel('z [mm]','interpreter','latex','FontSize',20)
ylabel('u [m/s]','interpreter','latex','FontSize',20)



Velocity_Data_Gas_shift2mm = Velocity_Data_Gas;
Velocity_Data_Gas_shift2mm.Z_mm_(:)=Velocity_Data_Gas_shift2mm.Z_mm_(:)+2;