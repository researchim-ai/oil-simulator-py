function [Measurement_Data_Labview_statistics,Measurement_Data_Labview] = LabView_Data_Manager(filename,ReG,ReL)
      %UNTITLED4 Summary of this function goes here
    %   Detailed explanation goes here
    % Mathematics
    xmin = 120; %start of sample section
    xmax = 20; % end of sample section
    range_setting = 2;
   % Load parameters, values from labview folder which are needed
    Cori_Offline = 'Mini_Cori_Flow'; % Coriflow NOT in use
    Measurement_Data_Raw.Cori_Flow =                             {'MF01','Timestamp_CF','Mass Flow'};
    Measurement_Data_Raw.Mini_Cori_Flow =                        {'MF02','Timestamp_CF','Mass Flow'};
    Measurement_Data_Raw.Density_Gas_LMF_Data=                   {'TT_Density','Timestamp_TT','Density'};
    Measurement_Data_Raw.Temperature_Gas_LMF_Data =              {'TT_Temperature','Timestamp_TT','Temperature'};
    Measurement_Data_Raw.Temperature_Gas_M_1_Data =              {'TC08','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Temperature_Gas_M_2_Data =              {'TC10','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Temperature_Gas_M_3_Data =              {'TC09','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Temperature_Gas_M_4_Data =              {'TC11','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Temperature_Gas_M_5_Data =              {'TC12','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Temperature_Liquid_M_inlet_Data =       {'TC14','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Temperature_Liquid_M_reservoir_Data =   {'TC13','Timestamp_TC','Temperature'};
    Measurement_Data_Raw.Absolute_Pressure_LMF_Data =            {'TT_AbsPressure','Timestamp_TT','Pressure'};
    Measurement_Data_Raw.Absolute_Pressure_M_Data =              {'AD_AbsPressure','Timestamp_AD','Pressure'};
    Measurement_Data_Raw.Relative_Pressure_M_Data =              {'AD_DiffPressure','Timestamp_AD','Pressure'};
    Measurement_Data_Raw.Volumeflow_Gas_LMF_Data =               {'TT_VolumeFlow','Timestamp_TT','Volume Flow'};
    Measurement_Data_Raw.Relative_Humidity_LMF_Data =            {'TT_RelativeHumidity','Timestamp_TT','Humidity'};  
    Measurement_Data_Raw.Viscosity_LMF_Data =                    {'TT_Viscosity','Untitled','Viscosity'};
    
    
    %%Load Data
    % Remove unwante coriflow 
    Measurement_Data_Raw = rmfield(Measurement_Data_Raw,Cori_Offline);
    Measurement_Data_Labview = Measurement_Data_Raw;
    Measurement_Data_Labview_statistics = Measurement_Data_Raw;
    % Load excel file 
    Mesurement_Data_Amount = numel(fieldnames(Measurement_Data_Raw));
    Measurement_Data_Fieldnames  = fieldnames(Measurement_Data_Raw);
    
    for ii = 1:Mesurement_Data_Amount
        Data_Label_Array = Measurement_Data_Raw.(Measurement_Data_Fieldnames{ii});
        Sheet_Name = Data_Label_Array{3}; %Sheet name in which data is located
        Timestamp_Name = Data_Label_Array{2}; % Timestamp of measurment 
        Data_Name = Data_Label_Array{1}; %specific Data that shall be extracted from excel file 
        raw_data_table = readtable(filename,'Sheet',Sheet_Name) ; %read excel file
        overhead=setdiff(raw_data_table.Properties.VariableNames,Data_Label_Array); % search for differences in sheet input and needed input
        data_table=removevars(raw_data_table,overhead); % get rid of excel table input not needed
        Measurement_Data_Labview.(Measurement_Data_Fieldnames{ii})=data_table; %write needed data into structure
    
    end
    
    
    
        %Waehle Range
        %Stelle default werte dar 
        xmin = length(Measurement_Data_Labview.Cori_Flow.Timestamp_CF)-xmin;
        xmax = length(Measurement_Data_Labview.Cori_Flow.Timestamp_CF)-xmax;
        
        
        while(range_setting==2)
            %respektive Zeiten im LMF
            tmin_cori = Measurement_Data_Labview.Cori_Flow.Timestamp_CF(xmin);
            tmax_cori = Measurement_Data_Labview.Cori_Flow.Timestamp_CF(xmax);
            endtime_LMF=Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(end);
            secondlasttime_LMF=Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(end-1);
            % unter umstaenden kann es sein, dass die Zeitaufzeichnung des LMF
            % vor dem Cori endet, weshalb hier eine Sicherheitsabfrage
            % stattfindet, welche diesen fehler abfaengt un die maximalzeit des
            % m auswahlzeitfensters auf die LMF aufnahmezeit begrenzt ( minus 3
            % zeitschrittee zur sicherheit)
            if (tmax_cori > endtime_LMF)
                warning('letzter Aufnahmezeitpunkt von TetraTec vor letztem gewaehlten Aufnahmezeitpunkt von Coriflow')
                tmax_cori = Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(end-3);
                tmax_cori = interp1(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:),Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:),tmax_cori,'nearest');
                xmax = find(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:)==tmax_cori);
                %sicherheitsabfrage um zu schauen, ob der neue gewaehlte
                %maximale Zeitwert kleiner als der minimale 
                if (tmax_cori < tmin_cori)
                    tmin_cori = Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(end-23);
                    tmin_cori = interp1(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:),Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:),tmin_cori,'nearest');
                    xmin = find(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:)==tmin_cori);
                end
            end
              %checke sicherheitshalber auch ob die startzeit des aufnahmebereichs kleiner ist
              %als der letzte wert
            if (tmin_cori> endtime_LMF)
                warning('letzter Aufnahmezeitpunkt von TetraTec vor erste, Aufnahmezeitpunkt vom Coriflow, Zeitfenster wird angepasst');
                tmin_cori =Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(end-33); %Passe startzeitpunkt INDEX an
                tmin_cori = interp1(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:), Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:), tmin_cori, 'nearest'); %Interpoliere Startzeitpunkt
                xmin = find(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:)==tmin_cori);
            % checke nach groeßter Zeit im LMF um ggf. das Maximum anzupassen
            end
            % checke ob der vorletzte Zeitpunk der LFM aufnahme kleiner ist
            % als die startzeit des Aufnahmebereichs des Coriflows
            % Das ist notwenig um interploation sicherzustellen
            if (tmin_cori> secondlasttime_LMF)
                warning('vorletzter Aufnahmezeitpunkt von TetraTec vor erstem Aufnahmezeitpunkt vom Coriflow, Zeitfenster wird angepasst');
                tmin_cori =Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(end-53); %Passe startzeitpunkt an
                tmin_cori = interp1(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:), Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:), tmin_cori, 'nearest');
                xmin = find(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(:)==tmin_cori);
            % checke nach groeßter Zeit im LMF um ggf. das Maximum anzupassen
            end
           
            
            tmin_LMF=interp1(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(:),Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(:),tmin_cori,'nearest');
            tmax_LMF=interp1(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(:),Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(:),tmax_cori,'nearest');
            index_tmin_LMF = find(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(:)==tmin_LMF);
            index_tmax_LMF = find(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(:)==tmax_LMF);
            
            
            
            %2)Plotte verlaeufe  
            f = figure();
            subplot(3,1,1);
            plot(Measurement_Data_Labview.Cori_Flow.MF01)
            xline(xmin,'-','start')
            xline(xmax,'-','end')
            
            subplot(3,1,2); 
            plot(Measurement_Data_Labview.Cori_Flow.Timestamp_CF,Measurement_Data_Labview.Cori_Flow.MF01)
            xline(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(xmin),'-','start')
            xline(Measurement_Data_Labview.Cori_Flow.Timestamp_CF(xmax),'-','end')
            title(ReL)
            
            subplot(3,1,3); 
            plot(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT,Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.TT_VolumeFlow)
            xline(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(index_tmin_LMF),'-','start')
            xline(Measurement_Data_Labview.Volumeflow_Gas_LMF_Data.Timestamp_TT(index_tmax_LMF),'-','end')
            title(ReG)
            uiwait(f);
                        
             % Abfragen ob mit dem zeitfenster alles passt
             answer = questdlg('section stationary', ...
	        'section stationary ?', ...
	        'Yes','Change selection range','Do NOT use this data','Do NOT use this data');
              % Handle response
              switch answer

                case 'Yes'
                    range_setting = 1;
                case 'Change selection range'
                    range_setting = 2;
                case 'Do NOT use this data'
                    range_setting = 3;
              end
        
            if (range_setting==2)
            
                    prompt = {'Enter new min value:','Enter new max value:'};
                    dlgtitle = 'Input';
                    fieldsize = [1 45; 1 45];
                    definput = {'200',num2str(length(Measurement_Data_Labview.Cori_Flow.MF01)-3)};
                    answer = inputdlg(prompt,dlgtitle,fieldsize,definput);
                    xmin = str2num(answer{1});
                    xmax = str2num(answer{2});
                    clf;
            end
            
        end
        
        %%Anpassen der Range auf andere Werte
        %Density_Gas-LMF_Data
        if (range_setting~=3)
        
            % Hier weiterarbeiten !!!
            Mesurement_Data_Amount = numel(fieldnames(Measurement_Data_Labview));
            Measurement_Data_Fieldnames  = fieldnames(Measurement_Data_Labview);
            
            % Hier weiterarbeiten !!!
            for kk = 1:Mesurement_Data_Amount
                TT = table2timetable(Measurement_Data_Labview.(Measurement_Data_Fieldnames{kk}));
                TT=TT(~any(ismissing(TT),2),:);
                rangeOfTimes = timerange(tmin_cori,tmax_cori);
                [tf,whichRows] = withinrange(TT,rangeOfTimes);
                TT2 = TT(whichRows,:);
                %TT_outlier = rmoutliers(TT2,"mean")
                TT2 = timetable2table(TT2);
                %NaN werte netfernen
                TT2 = rmmissing(TT2,'DataVariables',@isnumeric);
                %Outliers entfernen und alarm geben, wenn was nicht stimmt
                % https://de.mathworks.com/help/matlab/ref/isoutlier.html (Median
                % methode (Default), erstmal auf eis, evtl Marwan fragen
                %[Outliers,L,U,C] = varfun(@isoutlier, TT2, 'InputVariables',@isnumeric);     
                %Mittelwerte & Standardabweichung bestimmen
                Mean = varfun(@mean, TT2, 'InputVariables', @isnumeric);
                Std = varfun(@std, TT2, 'InputVariables', @isnumeric);
                Max = varfun(@max, TT2, 'InputVariables', @isnumeric);
                Min = varfun(@min, TT2, 'InputVariables', @isnumeric);
                TT2_statistics = [Mean,Std,Max,Min];
                Measurement_Data_Labview_statistics.(Measurement_Data_Fieldnames{kk})=TT2_statistics;
                Measurement_Data_Labview.(Measurement_Data_Fieldnames{kk})=TT2;

            end
        else

          Measurement_Data_Labview_statistics='No Statistics done due to unconsistent measurement data, see table';
       
        end

end