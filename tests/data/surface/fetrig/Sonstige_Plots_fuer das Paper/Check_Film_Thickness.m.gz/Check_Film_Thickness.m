%% berechung der Filmdicke nach verschiedenen Modellen

% Stoffdaten etc
rho_liq = 998.2; %Dichte in kg/m³
mu_liq = 1.0016*10^-3; %Viskosität in Pas
g = 9.81; % Erdbeschleunigung in m/s²


% sonst Daten
B = 0.1; %plattenbreite in meter

m_liq_kgh = 340;
m_liq = m_liq_kgh/3600;


% Berechnung der Filmreynoldszahl
Re_delta = m_liq/(B*mu_liq);
Re_film = 4*m_liq/(B*mu_liq);

% Versch.  Filmdickenkorrelationen 

h_nusselt = (3/4)^(1/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^(1/3); % gültig fuer Re_film < 1600

h_takahama = 0.473*(1/4)^(0.526)*(mu_liq^(2)/(rho_liq^(2)*g))^(1/3)*Re_film^(0.526); % gültig fuer 1470 < Re_film < 8000

h_geodecke = 0.3035*(1/4)^(1/3)*(mu_liq^(2)/(rho_liq^(2)*g))^(1/3)*Re_film^(1/3); % gueltig füer 600 < Re_film < 2400

h_karpantsios = 0.451*(1/4)^(0.538)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^0.538; % gültig für 360 < Re_film < 11020

h_brauer = 0.435*(1/4)^(8/15)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^(8/15);

h_gimbutis = 0.136*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^0.538;

h_mudawar = 0.324*(1/4)^0.58*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^(0.58);

h_Kockmann = 0.104*(3/8)^(1/3)*(1/4)^(7/12)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^(7/12); %gültig für 1000 < Re_film < 4000

h_ye = 0.295*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^0.498;

h_siebeneck = 0.345*(1/4)^(0.546)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^0.546;

h_feind = 0.137^(2/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^0.5;

h_brauer_fully_turbulent = 0.172*(1/4)^(2/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*Re_film^(2/3);