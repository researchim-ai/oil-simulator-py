%% Matlab Script for generatinb plots and automated Reports 

%% Read the desired data
load('MC_RC_Water_RH80_T25Deg_CopperPlate_28_08_24/Measurement_Database.mat')

sample_rate = 5000;% Sample rate [Hz]

%% Post process the data
%test navigate throug the tree structure
keyence_table = Measurement_Database.Y_350.X_50.ReG4900.ReL740.Keyence.table;

figure(1)
plot(keyence_table.TriggerCount, keyence_table.OUT01_mm_);

[keyence_cleared,i,xmedian,xsigma] = hampel(keyence_table.OUT01_mm_);
%get rid of outliers (outlier algortihm, https://de.mathworks.com/help/matlab/data_analysis/data-smoothing-and-outlier-detection.html)
figure (2)
Film_height = filloutliers(keyence_table.OUT01_mm_,"makima","gesd");
plot(keyence_table.TriggerCount,keyence_table.OUT01_mm_,keyence_table.TriggerCount,Film_height,"o-")
axis tight
legend("Noisy Data with Outlier","Noisy Data with Filled Outlier")
figure(3)
plot(keyence_table.TriggerCount,Film_height)
ylim([0,0.8])
xlim([6.2392*10^7,6.23924*10^7])

%wavelet transformation
fb = cwtfilterbank;

freqz(fb)
psi = wavelets(fb);
F = centerFrequencies(fb);
figure(3)
plot(real(psi(9,:)))
ylabel("Amplitude")
yyaxis right
plot(real(psi(end-16,:)))
ylabel("Amplitude")
axis tight
S1 = "Wavelets With Center Frequencies";
S2 = [num2str(F(9),"%1.2f")+" and "+num2str(F(end-16),"%1.2f")+" cycles/sample"];
title([S1,S2])
xlabel("Sample")
legend("0.25 c/s Wavelet","0.01 c/s Wavelet")

numFilters10 = nnz(F>=0.2 & F<=0.4);
fb = cwtfilterbank(VoicesPerOctave=8);
figure(4)
freqz(fb)
F = centerFrequencies(fb);
numFilters8 = nnz(F>=0.2 & F<=0.4);

load hyperbolicChirp
figure
plot(t,hyperbolchirp)
axis tight
xlabel("Time (s)")
ylabel("Amplitude")
title("Hyperbolic Chirp")

Fs = 1/mean(diff(t));
[cfs,f] = cwt(hyperbolchirp,Fs);
helperHyperbolicChirpPlot(cfs,f,t)

load wecg
tm = 0:1/180:numel(wecg)*1/180-1/180;
plot(tm,wecg)
grid on
axis tight
title("Human ECG")
xlabel("Time (s)")
ylabel("Amplitude")

[cfs,f] = cwt(wecg,180);
imagesc(tm,f,abs(cfs))
xlabel("Time (s)")
ylabel("Frequency (Hz)")
axis xy
clim([0.025 0.25])
title("CWT of ECG Data")

t_film = 0:1/sample_rate:numel(Film_height)*1/sample_rate-1/sample_rate;
figure(4)
plot(t_film,Film_height)
grid on
axis tight
title("Film THickness Data")
xlabel("Time (s)")
ylabel("Film Thickness")

[cfs,f] = cwt(Film_height,sample_rate);
figure(5)
imagesc(t_film,f,abs(cfs))
xlabel("Time (s)")
ylabel("Frequency (Hz)")
axis xy
clim([0.025 0.25])
title("CWT of Film Thickness Data")


pspectrum(Film_height,sample_rate,'Film_height','TimeResolution',4)
% check the spectral properties of the signal

%% Create the plots

%% create the report
%Check why this does not work.....
openExample('rptgen/MatlabReportGeneratorSupportFilesExample');
import mlreportgen.report.*; 
import mlreportgen.dom.* ;
rpt = Report('magic','html'); 
tp = TitlePage; 
tp.Title = 'Magic Squares'; 
tp.Subtitle = 'Columns, Rows, Diagonals: All Equal Sums'; 
tp.Author = 'Albrecht Durer'; 
append(rpt,tp); 

load wecg
tm = 0:1/180:numel(wecg)*1/180-1/180;
plot(tm,wecg)
grid on
axis tight
title("Human ECG")
xlabel("Time (s)")
ylabel("Amplitude")