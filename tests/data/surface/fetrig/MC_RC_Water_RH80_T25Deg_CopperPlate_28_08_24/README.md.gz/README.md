# FETRig
Post_Process_Data_Handling is the main post processing file and must be located one layer above the measurmement data Folder

Auswaehlen der Post_Process_Data_Handling.mlx in Current folder in matlab und ausfuehren mit F9
