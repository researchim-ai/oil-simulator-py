function [Measurement_Data_Keyence_statistics,Measurement_Data_Keyence] = Keyence_Data_Manager(filename)
    %USorting Keyence film thickness data (if necessary, and generating
    %statistical data)
    %   Detailed explanation goes here
    raw_data_table = readtable(filename);
    %sort out all values that are sorted out by the keyence system
    n_idx_go=find(strcmp(raw_data_table.Var3,'GO')==1);
    n_idx_alarm=find(strcmp(raw_data_table.Var3,'ALARM')==1);
    percentage_keyence_OK = numel(n_idx_go)/(numel(n_idx_alarm)+numel(n_idx_go))*100;
    mean_film_thickness__mm = mean(raw_data_table.OUT01_mm_(n_idx_go));
    std_film_thickness_mm = std(raw_data_table.OUT01_mm_(n_idx_go));
    max_film_thickness_mm = max(raw_data_table.OUT01_mm_(n_idx_go));
    min_film_thcikness_mm = min(raw_data_table.OUT01_mm_(n_idx_go));
    
   
    % calculate the elapsed time and add it to the Keyence data table
    opts = delimitedTextImportOptions("NumVariables", 3);
    % Specify range and delimiter
    opts.DataLines = [2, 2];
    opts.Delimiter = ",";
    sampling_info = readtable(filename, opts);
    sampling_array = strsplit(sampling_info{1,2}{1,1},'u');

    if (size(sampling_array,2)==2)
        time_step_factor = str2double(sampling_array(1,1))*10^-6;
    else
        warning('Keyence Timestep not in microseconds, please check the csv file')
        time_step_factor = 1;
    end
    time_step_sec = time_step_factor*(raw_data_table.TriggerCount(:)-raw_data_table.TriggerCount(1));
    raw_data_table = addvars(raw_data_table,time_step_sec);
    Film_height_cleaned_mm = filloutliers(raw_data_table.OUT01_mm_,"makima","gesd");
    raw_data_table = addvars(raw_data_table,Film_height_cleaned_mm);
  

    Measurement_Data_Keyence_statistics = table(mean_film_thickness__mm,std_film_thickness_mm,max_film_thickness_mm,min_film_thcikness_mm,percentage_keyence_OK);
    Measurement_Data_Keyence=raw_data_table;

end