clear all
cla
clf
sampling_rate = 200; % sampling rate in microseconds

%positions
X100 = 100; %100mm
X350 = 350; %250mm distance from inlet 
X600 = 600; %600mm distance from inlet
Position_Array = [X100,X350,X600];

A= load('/home/mwi/Documents/bwSyncShare/bwSync/Documents/00_Publikationen/Review of Scientific Instruments/Daten/Film Data_MC_RC_Water_RH80_T25Deg_CopperPlate_28_08_24/MC_RC_Water_RH80_T25Deg_CopperPlate_28_08_24/MC_RC_Water_RH80_T25Deg_CopperPlate_28_08_24_Measurement_Database.mat');
% Individuelle verlaufsdaten
%% Preprocessing der Daten
X100_ReG0_ReL500_Verlauf = A.Measurement_Database.Y_100.X_50.ReG0.ReL500.Keyence.table;
X350_ReG0_ReL500_Verlauf = A.Measurement_Database.Y_350.X_50.ReG0.ReL500.Keyence.table;
X600_ReG0_ReL500_Verlauf = A.Measurement_Database.Y_600.X_50.ReG0.ReL500.Keyence.table;

X100_ReG0_ReL620_Verlauf = A.Measurement_Database.Y_100.X_50.ReG0.ReL620.Keyence.table;
X350_ReG0_ReL620_Verlauf = A.Measurement_Database.Y_350.X_50.ReG0.ReL620.Keyence.table;
X600_ReG0_ReL620_Verlauf = A.Measurement_Database.Y_600.X_50.ReG0.ReL620.Keyence.table;
% Statistische Daten
%REG=0
%ReL500 ReG0
X100_ReG0_ReL500_statistik = A.Measurement_Database.Y_100.X_50.ReG0.ReL500.Keyence.statistics;
X350_ReG0_ReL500_statistik = A.Measurement_Database.Y_350.X_50.ReG0.ReL500.Keyence.statistics;
X600_ReG0_ReL500_statistik = A.Measurement_Database.Y_600.X_50.ReG0.ReL500.Keyence.statistics;
%ReL620 Reg0
X100_ReG0_ReL620_statistik = A.Measurement_Database.Y_100.X_50.ReG0.ReL620.Keyence.statistics;
X350_ReG0_ReL620_statistik = A.Measurement_Database.Y_350.X_50.ReG0.ReL620.Keyence.statistics;
X600_ReG0_ReL620_statistik = A.Measurement_Database.Y_600.X_50.ReG0.ReL620.Keyence.statistics;
%ReL740 Reg0
X100_ReG0_ReL740_statistik = A.Measurement_Database.Y_100.X_50.ReG0.ReL740.Keyence.statistics;
X350_ReG0_ReL740_statistik = A.Measurement_Database.Y_350.X_50.ReG0.ReL740.Keyence.statistics;
X600_ReG0_ReL740_statistik = A.Measurement_Database.Y_600.X_50.ReG0.ReL740.Keyence.statistics;
%ReL860 Reg0
X100_ReG0_ReL860_statistik = A.Measurement_Database.Y_100.X_50.ReG0.ReL860.Keyence.statistics;
X350_ReG0_ReL860_statistik = A.Measurement_Database.Y_350.X_50.ReG0.ReL860.Keyence.statistics;
X600_ReG0_ReL860_statistik = A.Measurement_Database.Y_600.X_50.ReG0.ReL860.Keyence.statistics;
%ReL980 Reg0
X100_ReG0_ReL980_statistik = A.Measurement_Database.Y_100.X_50.ReG0.ReL980.Keyence.statistics;
X350_ReG0_ReL980_statistik = A.Measurement_Database.Y_350.X_50.ReG0.ReL980.Keyence.statistics;
X600_ReG0_ReL980_statistik = A.Measurement_Database.Y_600.X_50.ReG0.ReL980.Keyence.statistics;
%ReL1100 Reg0
X100_ReG0_ReL1100_statistik = A.Measurement_Database.Y_100.X_50.ReG0.ReL1100.Keyence.statistics;
X350_ReG0_ReL1100_statistik = A.Measurement_Database.Y_350.X_50.ReG0.ReL1100.Keyence.statistics;
X600_ReG0_ReL1100_statistik = A.Measurement_Database.Y_600.X_50.ReG0.ReL1100.Keyence.statistics;

%REG=4900
%ReL500 ReG4900
X100_ReG4900_ReL500_statistik = A.Measurement_Database.Y_100.X_50.ReG4900.ReL500.Keyence.statistics;
X350_ReG4900_ReL500_statistik = A.Measurement_Database.Y_350.X_50.ReG4900.ReL500.Keyence.statistics;
X600_ReG4900_ReL500_statistik = A.Measurement_Database.Y_600.X_50.ReG4900.ReL500.Keyence.statistics;
%ReL620 Reg4900
X100_ReG4900_ReL620_statistik = A.Measurement_Database.Y_100.X_50.ReG4900.ReL620.Keyence.statistics;
X350_ReG4900_ReL620_statistik = A.Measurement_Database.Y_350.X_50.ReG4900.ReL620.Keyence.statistics;
X600_ReG4900_ReL620_statistik = A.Measurement_Database.Y_600.X_50.ReG4900.ReL620.Keyence.statistics;
%ReL740 Reg0
X100_ReG4900_ReL740_statistik = A.Measurement_Database.Y_100.X_50.ReG4900.ReL740.Keyence.statistics;
X350_ReG4900_ReL740_statistik = A.Measurement_Database.Y_350.X_50.ReG4900.ReL740.Keyence.statistics;
X600_ReG4900_ReL740_statistik = A.Measurement_Database.Y_600.X_50.ReG4900.ReL740.Keyence.statistics;
%ReL860 Reg0
X100_ReG4900_ReL860_statistik = A.Measurement_Database.Y_100.X_50.ReG4900.ReL860.Keyence.statistics;
X350_ReG4900_ReL860_statistik = A.Measurement_Database.Y_350.X_50.ReG4900.ReL860.Keyence.statistics;
X600_ReG4900_ReL860_statistik = A.Measurement_Database.Y_600.X_50.ReG4900.ReL860.Keyence.statistics;
%ReL980 Reg0
X100_ReG4900_ReL980_statistik = A.Measurement_Database.Y_100.X_50.ReG4900.ReL980.Keyence.statistics;
X350_ReG4900_ReL980_statistik = A.Measurement_Database.Y_350.X_50.ReG4900.ReL980.Keyence.statistics;
X600_ReG4900_ReL980_statistik = A.Measurement_Database.Y_600.X_50.ReG4900.ReL980.Keyence.statistics;
%ReL1100 Reg0
X100_ReG4900_ReL1100_statistik = A.Measurement_Database.Y_100.X_50.ReG4900.ReL1100.Keyence.statistics;
X350_ReG4900_ReL1100_statistik = A.Measurement_Database.Y_350.X_50.ReG4900.ReL1100.Keyence.statistics;
X600_ReG4900_ReL1100_statistik = A.Measurement_Database.Y_600.X_50.ReG4900.ReL1100.Keyence.statistics;

%REG=8900
%ReL500 
X100_ReG8900_ReL500_statistik = A.Measurement_Database.Y_100.X_50.ReG8900.ReL500.Keyence.statistics;
X350_ReG8900_ReL500_statistik = A.Measurement_Database.Y_350.X_50.ReG8900.ReL500.Keyence.statistics;
X600_ReG8900_ReL500_statistik = A.Measurement_Database.Y_600.X_50.ReG8900.ReL500.Keyence.statistics;
%ReL620
X100_ReG8900_ReL620_statistik = A.Measurement_Database.Y_100.X_50.ReG8900.ReL620.Keyence.statistics;
X350_ReG8900_ReL620_statistik = A.Measurement_Database.Y_350.X_50.ReG8900.ReL620.Keyence.statistics;
X600_ReG8900_ReL620_statistik = A.Measurement_Database.Y_600.X_50.ReG8900.ReL620.Keyence.statistics;
%ReL740
X100_ReG8900_ReL740_statistik = A.Measurement_Database.Y_100.X_50.ReG8900.ReL740.Keyence.statistics;
X350_ReG8900_ReL740_statistik = A.Measurement_Database.Y_350.X_50.ReG8900.ReL740.Keyence.statistics;
X600_ReG8900_ReL740_statistik = A.Measurement_Database.Y_600.X_50.ReG8900.ReL740.Keyence.statistics;
%ReL860
X100_ReG8900_ReL860_statistik = A.Measurement_Database.Y_100.X_50.ReG8900.ReL860.Keyence.statistics;
X350_ReG8900_ReL860_statistik = A.Measurement_Database.Y_350.X_50.ReG8900.ReL860.Keyence.statistics;
X600_ReG8900_ReL860_statistik = A.Measurement_Database.Y_600.X_50.ReG8900.ReL860.Keyence.statistics;
%ReL980
X100_ReG8900_ReL980_statistik = A.Measurement_Database.Y_100.X_50.ReG8900.ReL980.Keyence.statistics;
X350_ReG8900_ReL980_statistik = A.Measurement_Database.Y_350.X_50.ReG8900.ReL980.Keyence.statistics;
X600_ReG8900_ReL980_statistik = A.Measurement_Database.Y_600.X_50.ReG8900.ReL980.Keyence.statistics;
%ReL1100
X100_ReG8900_ReL1100_statistik = A.Measurement_Database.Y_100.X_50.ReG8900.ReL1100.Keyence.statistics;
X350_ReG8900_ReL1100_statistik = A.Measurement_Database.Y_350.X_50.ReG8900.ReL1100.Keyence.statistics;
X600_ReG8900_ReL1100_statistik = A.Measurement_Database.Y_600.X_50.ReG8900.ReL1100.Keyence.statistics;

%REG=12900
%ReL500
X100_ReG12900_ReL500_statistik = A.Measurement_Database.Y_100.X_50.ReG12900.ReL500.Keyence.statistics;
X350_ReG12900_ReL500_statistik = A.Measurement_Database.Y_350.X_50.ReG12900.ReL500.Keyence.statistics;
X600_ReG12900_ReL500_statistik = A.Measurement_Database.Y_600.X_50.ReG12900.ReL500.Keyence.statistics;
%ReL620
X100_ReG12900_ReL620_statistik = A.Measurement_Database.Y_100.X_50.ReG12900.ReL620.Keyence.statistics;
X350_ReG12900_ReL620_statistik = A.Measurement_Database.Y_350.X_50.ReG12900.ReL620.Keyence.statistics;
X600_ReG12900_ReL620_statistik = A.Measurement_Database.Y_600.X_50.ReG12900.ReL620.Keyence.statistics;
%ReL740
X100_ReG12900_ReL740_statistik = A.Measurement_Database.Y_100.X_50.ReG12900.ReL740.Keyence.statistics;
X350_ReG12900_ReL740_statistik = A.Measurement_Database.Y_350.X_50.ReG12900.ReL740.Keyence.statistics;
X600_ReG12900_ReL740_statistik = A.Measurement_Database.Y_600.X_50.ReG12900.ReL740.Keyence.statistics;
%ReL860
X100_ReG12900_ReL860_statistik = A.Measurement_Database.Y_100.X_50.ReG12900.ReL860.Keyence.statistics;
X350_ReG12900_ReL860_statistik = A.Measurement_Database.Y_350.X_50.ReG12900.ReL860.Keyence.statistics;
X600_ReG12900_ReL860_statistik = A.Measurement_Database.Y_600.X_50.ReG12900.ReL860.Keyence.statistics;
%ReL980
X100_ReG12900_ReL980_statistik = A.Measurement_Database.Y_100.X_50.ReG12900.ReL980.Keyence.statistics;
X350_ReG12900_ReL980_statistik = A.Measurement_Database.Y_350.X_50.ReG12900.ReL980.Keyence.statistics;
X600_ReG12900_ReL980_statistik = A.Measurement_Database.Y_600.X_50.ReG12900.ReL980.Keyence.statistics;
%ReL1100
X100_ReG12900_ReL1100_statistik = A.Measurement_Database.Y_100.X_50.ReG12900.ReL1100.Keyence.statistics;
X350_ReG12900_ReL1100_statistik = A.Measurement_Database.Y_350.X_50.ReG12900.ReL1100.Keyence.statistics;
X600_ReG12900_ReL1100_statistik = A.Measurement_Database.Y_600.X_50.ReG12900.ReL1100.Keyence.statistics;

%REG=16900
%ReL500 
X100_ReG16900_ReL500_statistik = A.Measurement_Database.Y_100.X_50.ReG16900.ReL500.Keyence.statistics;
X350_ReG16900_ReL500_statistik = A.Measurement_Database.Y_350.X_50.ReG16900.ReL500.Keyence.statistics;
X600_ReG16900_ReL500_statistik = A.Measurement_Database.Y_600.X_50.ReG16900.ReL500.Keyence.statistics;
%ReL620 Reg0
X100_ReG16900_ReL620_statistik = A.Measurement_Database.Y_100.X_50.ReG16900.ReL620.Keyence.statistics;
X350_ReG16900_ReL620_statistik = A.Measurement_Database.Y_350.X_50.ReG16900.ReL620.Keyence.statistics;
X600_ReG16900_ReL620_statistik = A.Measurement_Database.Y_600.X_50.ReG16900.ReL620.Keyence.statistics;
%ReL740 Reg0
X100_ReG16900_ReL740_statistik = A.Measurement_Database.Y_100.X_50.ReG16900.ReL740.Keyence.statistics;
X350_ReG16900_ReL740_statistik = A.Measurement_Database.Y_350.X_50.ReG16900.ReL740.Keyence.statistics;
X600_ReG16900_ReL740_statistik = A.Measurement_Database.Y_600.X_50.ReG16900.ReL740.Keyence.statistics;
%ReL860 Reg0
X100_ReG16900_ReL860_statistik = A.Measurement_Database.Y_100.X_50.ReG16900.ReL860.Keyence.statistics;
X350_ReG16900_ReL860_statistik = A.Measurement_Database.Y_350.X_50.ReG16900.ReL860.Keyence.statistics;
X600_ReG16900_ReL860_statistik = A.Measurement_Database.Y_600.X_50.ReG16900.ReL860.Keyence.statistics;
%ReL980 Reg0
X100_ReG16900_ReL980_statistik = A.Measurement_Database.Y_100.X_50.ReG16900.ReL980.Keyence.statistics;
X350_ReG16900_ReL980_statistik = A.Measurement_Database.Y_350.X_50.ReG16900.ReL980.Keyence.statistics;
X600_ReG16900_ReL980_statistik = A.Measurement_Database.Y_600.X_50.ReG16900.ReL980.Keyence.statistics;
%ReL1100 Reg0
X100_ReG16900_ReL1100_statistik = A.Measurement_Database.Y_100.X_50.ReG16900.ReL1100.Keyence.statistics;
X350_ReG16900_ReL1100_statistik = A.Measurement_Database.Y_350.X_50.ReG16900.ReL1100.Keyence.statistics;
X600_ReG16900_ReL1100_statistik = A.Measurement_Database.Y_600.X_50.ReG16900.ReL1100.Keyence.statistics;


%REG=20900
%ReL500 
X100_ReG20900_ReL500_statistik = A.Measurement_Database.Y_100.X_50.ReG20900.ReL500.Keyence.statistics;
X350_ReG20900_ReL500_statistik = A.Measurement_Database.Y_350.X_50.ReG20900.ReL500.Keyence.statistics;
X600_ReG20900_ReL500_statistik = A.Measurement_Database.Y_600.X_50.ReG20900.ReL500.Keyence.statistics;
%ReL620 Reg0
X100_ReG20900_ReL620_statistik = A.Measurement_Database.Y_100.X_50.ReG20900.ReL620.Keyence.statistics;
X350_ReG20900_ReL620_statistik = A.Measurement_Database.Y_350.X_50.ReG20900.ReL620.Keyence.statistics;
X600_ReG20900_ReL620_statistik = A.Measurement_Database.Y_600.X_50.ReG20900.ReL620.Keyence.statistics;
%ReL740 Reg0
X100_ReG20900_ReL740_statistik = A.Measurement_Database.Y_100.X_50.ReG20900.ReL740.Keyence.statistics;
X350_ReG20900_ReL740_statistik = A.Measurement_Database.Y_350.X_50.ReG20900.ReL740.Keyence.statistics;
X600_ReG20900_ReL740_statistik = A.Measurement_Database.Y_600.X_50.ReG20900.ReL740.Keyence.statistics;
%ReL860 Reg0
X100_ReG20900_ReL860_statistik = A.Measurement_Database.Y_100.X_50.ReG20900.ReL860.Keyence.statistics;
X350_ReG20900_ReL860_statistik = A.Measurement_Database.Y_350.X_50.ReG20900.ReL860.Keyence.statistics;
X600_ReG20900_ReL860_statistik = A.Measurement_Database.Y_600.X_50.ReG20900.ReL860.Keyence.statistics;
%ReL980 Reg0
X100_ReG20900_ReL980_statistik = A.Measurement_Database.Y_100.X_50.ReG20900.ReL980.Keyence.statistics;
X350_ReG20900_ReL980_statistik = A.Measurement_Database.Y_350.X_50.ReG20900.ReL980.Keyence.statistics;
X600_ReG20900_ReL980_statistik = A.Measurement_Database.Y_600.X_50.ReG20900.ReL980.Keyence.statistics;
%ReL1100 Reg0
X100_ReG20900_ReL1100_statistik = A.Measurement_Database.Y_100.X_50.ReG20900.ReL1100.Keyence.statistics;
X350_Reg20900_ReL1100_statistik = A.Measurement_Database.Y_350.X_50.ReG20900.ReL1100.Keyence.statistics;
X600_ReG20900_ReL1100_statistik = A.Measurement_Database.Y_600.X_50.ReG20900.ReL1100.Keyence.statistics;

%% Mittelwert Daten
%ReL500
ReG0_ReL500_mean_film_thickness = [X100_ReG0_ReL500_statistik.mean_film_thickness__mm,X100;...
                                   X350_ReG0_ReL500_statistik.mean_film_thickness__mm,X350;...
                                   X600_ReG0_ReL500_statistik.mean_film_thickness__mm,X600];
%ReL620
ReG0_ReL620_mean_film_thickness = [X100_ReG0_ReL620_statistik.mean_film_thickness__mm,X100;...
                                   X350_ReG0_ReL620_statistik.mean_film_thickness__mm,X350;...
                                   X600_ReG0_ReL620_statistik.mean_film_thickness__mm,X600];
%ReL740
ReG0_ReL740_mean_film_thickness = [X100_ReG0_ReL740_statistik.mean_film_thickness__mm,X100;...
                                   X350_ReG0_ReL740_statistik.mean_film_thickness__mm,X350;...
                                   X600_ReG0_ReL740_statistik.mean_film_thickness__mm,X600];
%ReL860
ReG0_ReL860_mean_film_thickness = [X100_ReG0_ReL860_statistik.mean_film_thickness__mm,X100;...
                                   X350_ReG0_ReL860_statistik.mean_film_thickness__mm,X350;...
                                   X600_ReG0_ReL860_statistik.mean_film_thickness__mm,X600];
%ReL980
ReG0_ReL980_mean_film_thickness = [X100_ReG0_ReL980_statistik.mean_film_thickness__mm,X100;...
                                   X350_ReG0_ReL980_statistik.mean_film_thickness__mm,X350;...
                                   X600_ReG0_ReL980_statistik.mean_film_thickness__mm,X600];
%ReL1100
ReG0_ReL1100_mean_film_thickness = [X100_ReG0_ReL1100_statistik.mean_film_thickness__mm,X100;...
                                   X350_ReG0_ReL1100_statistik.mean_film_thickness__mm,X350;...
                                   X600_ReG0_ReL1100_statistik.mean_film_thickness__mm,X600];
%% Zusätzliche filmdikenverlaufe aus der Literatur (stationaer)
% Stoffdaten etc bei 25°C fuer wasser 
rho_liq = 997; %Dichte in kg/m³
mu_liq = 0.89*10^-3; %Viskosität in Pas
g = 9.81; % Erdbeschleunigung in m/s²

%Berechnung der Filmreynoldszahl Achtung die Versuchsreynoldszahl mal 4!!
Re_film_selected = 4.*[500 620 740 860 980 1100];
Re_film_continuous = 4.*(100:10:1200);

% sonst Daten
B = 0.1; %plattenbreite in meter

% m_liq_kgh = 340;
% m_liq = m_liq_kgh/3600;


% Berechnung der Filmreynoldszahl
% Re_delta = m_liq/(B*mu_liq);
% Re_film = 4*m_liq/(B*mu_liq);

% Versch.  Filmdickenkorrelationen 
%h_nusselt_test = (3/4)^(1/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3)*400^(1/3);

h_nusselt = (3/4)^(1/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(1/3); % gültig fuer Re_film < 1600

h_takahama = 0.473*(1/4)^(0.526)*(mu_liq^(2)/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(0.526); % gültig fuer 1470 < Re_film < 8000

h_geodecke = 0.3035*(1/4)^(1/3)*(mu_liq^(2)/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(1/3); % gueltig füer 600 < Re_film < 2400

h_karpantsios = 0.451*(1/4)^(0.538)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^0.538; % gültig für 360 < Re_film < 11020

h_brauer = 0.435*(1/4)^(8/15)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(8/15);

h_gimbutis = 0.136*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^0.538;

h_mudawar = 0.324*(1/4)^0.58*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(0.58);

h_Kockmann = 0.104*(3/8)^(1/3)*(1/4)^(7/12)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(7/12); %gültig für 1000 < Re_film < 4000

h_ye = 0.295*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^0.498;

h_siebeneck = 0.345*(1/4)^(0.546)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^0.546;

h_feind = 0.137^(2/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^0.5;

h_brauer_fully_turbulent = 0.172*(1/4)^(2/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_continuous.^(2/3);

h_al_sibai = (1+0.615.*(Re_film_continuous./4).^(0.47))./((g*rho_liq^2/mu_liq^2)^(1/3));

h_nusselt_plot = (3/4)^(1/3)*(mu_liq^2/(rho_liq^(2)*g))^(1/3).*Re_film_selected.^(1/3); % gültig fuer Re_film < 1600

%% Zeitliche Verläufe
figure(1)
Film_Heigt_m = X350_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(1:1001)/1000;
plot(X350_ReG0_ReL500_Verlauf.time_step_sec(1:1001),X350_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[0,0,0]);
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Time [s]','interpreter','latex','FontSize',20)
ylabel('Film height [m]','interpreter','latex','FontSize',20)

ax.YAxis.Exponent = -3; % Set exponent for scientific notation

figure(2)
plot(X600_ReG0_ReL500_Verlauf.time_step_sec(1:1001),X600_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[0,0,0]);
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Time [s]','interpreter','latex','FontSize',20)
ylabel('Film height [m]','interpreter','latex','FontSize',20)
ax.YAxis.Exponent = -3; % Set exponent for scientific notation

figure(3)
plot(X100_ReG0_ReL500_Verlauf.time_step_sec(1:1001),X100_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[0,0,0]);
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Time [s]','interpreter','latex','FontSize',20)
ylabel('Film height [m]','interpreter','latex','FontSize',20)
ax.YAxis.Exponent = -3; % Set exponent for scientific notation
%% Vergleich von erstem und letztem Messpunkt ohne Re_G inklusive mittelwert
%Re500
figure(4)
plot1=plot(X100_ReG0_ReL500_Verlauf.time_step_sec(1:1001),X100_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[1,0,0]);
hold on 
plot2=plot(X600_ReG0_ReL500_Verlauf.time_step_sec(1:1001),X600_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[0,0,1]);
hold on

line1=yline(ReG0_ReL500_mean_film_thickness(1,1)/1000,'--');%Re_{liq} = 500, x=100mm'
line1.Color=[1 0 0];
line2=yline(ReG0_ReL500_mean_film_thickness(3,1)/1000,'--');%Re_{liq} = 500, x=600mm'
line2.Color=[0 0 1];
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Time [s]','interpreter','latex','FontSize',20)
ylabel('Film height [m]','interpreter','latex','FontSize',20)
ax.YAxis.Exponent = -3; % Set exponent for scientific notation
lgd1 = legend([plot1,plot2,line1,line2],{'Film Height x = 0.1 m', 'Film Height x = 0.6 m', 'Mean Height x = 0.1 m', 'Mean Height x = 0.6 m',}, 'Interpreter', 'latex','FontSize',16);
% lgd1.Location= 'northoutside';
% lgd1.Orientation= 'horizontal';
% lgd1.NumColumns =3;

%Re620
figure(5)
plot(X100_ReG0_ReL620_Verlauf.time_step_sec(1:1001),X100_ReG0_ReL620_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[1,0,0]);
hold on 
plot(X600_ReG0_ReL620_Verlauf.time_step_sec(1:1001),X600_ReG0_ReL620_Verlauf.Film_height_cleaned_mm(1:1001)/1000,'Color',[0,0,1]);
hold on

line1=yline(ReG0_ReL740_mean_film_thickness(1,1)/1000,':');%Re_{liq} = 620, x=100mm'
line1.Color=[1 0 0];
line2=yline(ReG0_ReL740_mean_film_thickness(3,1)/1000,'--');%Re_{liq} = 620, x=600mm'
line2.Color=[0 0 1];
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Time [s]','interpreter','latex','FontSize',20)
ylabel('Film height [m]','interpreter','latex','FontSize',20)
ax.YAxis.Exponent = -3; % Set exponent for scientific notation


%% Histogramme
%Dickenverteilung bei x=100mm
figure(6)
nbins = 25;
hist1=histogram(X100_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(:)/1000,nbins);
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Film height [m]','interpreter','latex','FontSize',20)
ylabel('Number','interpreter','latex','FontSize',20)


%Dickenverteilung bei x = 350mm
figure(7)
nbins = 25;
hist2=histogram(X350_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(:)/1000,nbins);
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Film height [m]','interpreter','latex','FontSize',20)
ylabel('Number','interpreter','latex','FontSize',20)

%ax.YAxis.Exponent = -3; % Set exponent for scientific notation

%Dickenverteilung bei x=600
figure(8)
nbins = 25;
hist3=histogram(X600_ReG0_ReL500_Verlauf.Film_height_cleaned_mm(:)/1000,nbins);
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
xlabel('Film height [m]','interpreter','latex','FontSize',20)
ylabel('Number','interpreter','latex','FontSize',20)

%ax.YAxis.Exponent = -3; % Set exponent for scientific notation



%% Filmdickenverlauf über die laenge bei ReG=0
figure(9)
h1=plot(ReG0_ReL500_mean_film_thickness(:,2)/1000,ReG0_ReL500_mean_film_thickness(:,1)/1000,'LineStyle','-','Marker','square',"Color",[0 0.4470 0.7410],"MarkerFaceColor",[0 0.4470 0.7410],"MarkerSize",8);
hold on
h2=plot(ReG0_ReL620_mean_film_thickness(:,2)/1000,ReG0_ReL620_mean_film_thickness(:,1)/1000,'LineStyle','-','Marker','diamond',"Color",[0.8500 0.3250 0.0980],"MarkerFaceColor",[0.8500 0.3250 0.0980],"MarkerSize",8);
hold on
h3=plot(ReG0_ReL740_mean_film_thickness(:,2)/1000,ReG0_ReL740_mean_film_thickness(:,1)/1000,'LineStyle','-','Marker','^',"Color",[0.4940 0.1840 0.5560],"MarkerFaceColor",[0.4940 0.1840 0.5560],"MarkerSize",8);
hold on
h4=plot(ReG0_ReL860_mean_film_thickness(:,2)/1000,ReG0_ReL860_mean_film_thickness(:,1)/1000,'LineStyle','-','Marker','v',"Color",[0.4660 0.6740 0.1880],"MarkerFaceColor",[0.4660 0.6740 0.1880],"MarkerSize",8);
hold on
h5=plot(ReG0_ReL980_mean_film_thickness(:,2)/1000,ReG0_ReL980_mean_film_thickness(:,1)/1000,'LineStyle','-','Marker','o',"Color",[0.6350 0.0780 0.1840],"MarkerFaceColor",[0.6350 0.0780 0.1840],"MarkerSize",8);
hold on
h6=plot(ReG0_ReL1100_mean_film_thickness(:,2)/1000,ReG0_ReL1100_mean_film_thickness(:,1)/1000,'LineStyle','-','Marker','pentagram',"Color",[0 0 0],"MarkerFaceColor",[0 0 0]);
hold on
y1=yline(h_nusselt_plot(1),'--','Re_{liq} = 500');
y1.Color=[0 0.4470 0.7410];
hold on
y2=yline(h_nusselt_plot(2),'--','Re_{liq} = 620');
y2.Color=[0.8500 0.3250 0.0980];
hold on
y3=yline(h_nusselt_plot(3),'--','Re_{liq} = 740');
y3.Color=[0.4940 0.1840 0.5560];
hold on
y4=yline(h_nusselt_plot(4),'--','Re_{liq} = 860');
y4.Color=[0.4660 0.6740 0.1880];
hold on
y5=yline(h_nusselt_plot(5),'--','Re_{liq} = 980');
y5.Color=[0.6350 0.0780 0.1840];
hold on
y6=yline(h_nusselt_plot(6),'--','Re_{liq} = 1100');
y6.Color=[0 0 0];


% Vergleich experiment vs Nusselt
ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
ax.YAxis.Exponent = -3; % Set exponent for scientific notation
xlabel('Distance [m]','interpreter','latex','FontSize',20)
ylabel('Average film height [m]','interpreter','latex','FontSize',20)
lgd1 = legend([h6,h5,h4,h3,h2,h1],{'$Re_{liq} = 1,100$', '$Re_{liq} = 980$', '$Re_{liq} = 860$', '$Re_{liq} = 740$', '$Re_{liq} = 620$', '$Re_{liq} = 500$'}, 'Interpreter', 'latex','FontSize',18);
lgd1.Location= 'northoutside';
lgd1.Orientation= 'horizontal';
lgd1.NumColumns =3;
ax.XLim=[0.050,0.700];

%% uebersicht aller Korellationen 
figure(10)

%g1=plot(Re_film_continuous,h_al_sibai);
hold on
g2=plot(Re_film_continuous./4,h_takahama,'LineStyle','--',"Color",[0 0 0]);
hold on
%g3=plot(Re_film_continuous./4,h_geodecke,'LineStyle','--');
hold on
%g4=plot(Re_film_continuous./4,h_karpantsios,'LineStyle','-.',"Color",[0 0 0]);
hold on
g5=plot(Re_film_continuous./4,h_gimbutis,'LineStyle','-.',"Color",[0 0 0]);
hold on
g6=plot(Re_film_continuous./4,h_mudawar,'LineStyle',':',"Color",[0 0 0]);
hold on
g7=plot(Re_film_continuous./4,h_brauer,'LineStyle','--',"Color",[0 0 0]);
%hold on
%g8=plot(Re_film_continuous,h_ye);
%hold on
%g9=plot(Re_film_continuous,h_feind);
hold on
g10=plot(Re_film_continuous./4,h_nusselt,'LineStyle','-',"Color",[0 0 0]);
% Messungen bei x = 600
g21=plot(500,ReG0_ReL500_mean_film_thickness(3,1)/1000,'Marker','square',"Color",[0 0.4470 0.7410],"MarkerFaceColor",[0 0.4470 0.7410],"MarkerSize",8);
hold on
g22=plot(620,ReG0_ReL620_mean_film_thickness(3,1)/1000,'Marker','diamond',"Color",[0.8500 0.3250 0.0980],"MarkerFaceColor",[0.8500 0.3250 0.0980],"MarkerSize",8);
hold on
g23=plot(740,ReG0_ReL740_mean_film_thickness(3,1)/1000,'Marker','^',"Color",[0.4940 0.1840 0.5560],"MarkerFaceColor",[0.4940 0.1840 0.5560],"MarkerSize",8);
hold on
g24=plot(860,ReG0_ReL860_mean_film_thickness(3,1)/1000,'Marker','v',"Color",[0.4660 0.6740 0.1880],"MarkerFaceColor",[0.4660 0.6740 0.1880],"MarkerSize",8);
hold on
g25=plot(980,ReG0_ReL980_mean_film_thickness(3,1)/1000,'Marker','o',"Color",[0.6350 0.0780 0.1840],"MarkerFaceColor",[0.6350 0.0780 0.1840],"MarkerSize",8);
hold on
g26=plot(1100,ReG0_ReL1100_mean_film_thickness(3,1)/1000,'Marker','pentagram',"Color",[0 0 0],"MarkerFaceColor",[0 0 0]);
% hold on
% % Hier noch Messungen Hinzufügen / x = 350
% g31=plot(500,ReG0_ReL500_mean_film_thickness(2,1)/1000,'Marker','diamond',"Color",[0 0.4470 0.7410],"MarkerFaceColor",[0 0.4470 0.7410],"MarkerSize",8);
% hold on
% g32=plot(620,ReG0_ReL620_mean_film_thickness(2,1)/1000,'Marker','diamond',"Color",[0.8500 0.3250 0.0980],"MarkerFaceColor",[0.8500 0.3250 0.0980],"MarkerSize",8);
% hold on
% g33=plot(740,ReG0_ReL740_mean_film_thickness(2,1)/1000,'Marker','diamond',"Color",[0.4940 0.1840 0.5560],"MarkerFaceColor",[0.4940 0.1840 0.5560],"MarkerSize",8);
% hold on
% g34=plot(860,ReG0_ReL860_mean_film_thickness(2,1)/1000,'Marker','diamond',"Color",[0.4660 0.6740 0.1880],"MarkerFaceColor",[0.4660 0.6740 0.1880],"MarkerSize",8);
% hold on
% g35=plot(980,ReG0_ReL980_mean_film_thickness(2,1)/1000,'Marker','diamond',"Color",[0.6350 0.0780 0.1840],"MarkerFaceColor",[0.6350 0.0780 0.1840],"MarkerSize",8);
% hold on
% g36=plot(1100,ReG0_ReL1100_mean_film_thickness(2,1)/1000,'Marker','diamond',"Color",[0 0 0],"MarkerFaceColor",[0 0 0]);
% hold on
% % Messungen bei x = 100
% g41=plot(500,ReG0_ReL500_mean_film_thickness(1,1)/1000,'Marker','o',"Color",[0 0.4470 0.7410],"MarkerFaceColor",[0 0.4470 0.7410],"MarkerSize",8);
% hold on
% g42=plot(620,ReG0_ReL620_mean_film_thickness(1,1)/1000,'Marker','o',"Color",[0.8500 0.3250 0.0980],"MarkerFaceColor",[0.8500 0.3250 0.0980],"MarkerSize",8);
% hold on
% g43=plot(740,ReG0_ReL740_mean_film_thickness(1,1)/1000,'Marker','o',"Color",[0.4940 0.1840 0.5560],"MarkerFaceColor",[0.4940 0.1840 0.5560],"MarkerSize",8);
% hold on
% g44=plot(860,ReG0_ReL860_mean_film_thickness(1,1)/1000,'Marker','o',"Color",[0.4660 0.6740 0.1880],"MarkerFaceColor",[0.4660 0.6740 0.1880],"MarkerSize",8);
% hold on
% g45=plot(980,ReG0_ReL980_mean_film_thickness(1,1)/1000,'Marker','o',"Color",[0.6350 0.0780 0.1840],"MarkerFaceColor",[0.6350 0.0780 0.1840],"MarkerSize",8);
% hold on
% g46=plot(1100,ReG0_ReL1100_mean_film_thickness(1,1)/1000,'Marker','o',"Color",[0 0 0],"MarkerFaceColor",[0 0 0]);



lgd = legend([g10,g7,g6,g5,g2],{'Nusselt', 'Brauer', 'Mudawar', 'Gimbutis', 'Takahama'}, 'Interpreter', 'latex','FontSize',18);
lgd.Location= 'northoutside';
lgd.Orientation= 'horizontal';
lgd.NumColumns =3;







%% Einfluss von ReG Filmdicke bei X = 100

ReGVar_ReL500_X100_mean_film_thickness = [ X100_ReG0_ReL500_statistik.mean_film_thickness__mm,0;...
                                   X100_ReG4900_ReL500_statistik.mean_film_thickness__mm,4900;...
                                   X100_ReG8900_ReL500_statistik.mean_film_thickness__mm,8900;...
                                   X100_ReG12900_ReL500_statistik.mean_film_thickness__mm,12900;...
                                   X100_ReG16900_ReL500_statistik.mean_film_thickness__mm,16900;...
                                   X100_ReG20900_ReL500_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL620_X100_mean_film_thickness = [ X100_ReG0_ReL620_statistik.mean_film_thickness__mm,0;...
                                   X100_ReG4900_ReL620_statistik.mean_film_thickness__mm,4900;...
                                   X100_ReG8900_ReL620_statistik.mean_film_thickness__mm,8900;...
                                   X100_ReG12900_ReL620_statistik.mean_film_thickness__mm,12900;...
                                   X100_ReG16900_ReL620_statistik.mean_film_thickness__mm,16900;...
                                   X100_ReG20900_ReL620_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL740_X100_mean_film_thickness = [ X100_ReG0_ReL740_statistik.mean_film_thickness__mm,0;...
                                   X100_ReG4900_ReL740_statistik.mean_film_thickness__mm,4900;...
                                   X100_ReG8900_ReL740_statistik.mean_film_thickness__mm,8900;...
                                   X100_ReG12900_ReL740_statistik.mean_film_thickness__mm,12900;...
                                   X100_ReG16900_ReL740_statistik.mean_film_thickness__mm,16900;...
                                   X100_ReG20900_ReL740_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL860_X100_mean_film_thickness = [ X100_ReG0_ReL860_statistik.mean_film_thickness__mm,0;...
                                   X100_ReG4900_ReL860_statistik.mean_film_thickness__mm,4900;...
                                   X100_ReG8900_ReL860_statistik.mean_film_thickness__mm,8900;...
                                   X100_ReG12900_ReL860_statistik.mean_film_thickness__mm,12900;...
                                   X100_ReG16900_ReL860_statistik.mean_film_thickness__mm,16900;...
                                   X100_ReG20900_ReL860_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL980_X100_mean_film_thickness = [ X100_ReG0_ReL980_statistik.mean_film_thickness__mm,0;...
                                   X100_ReG4900_ReL980_statistik.mean_film_thickness__mm,4900;...
                                   X100_ReG8900_ReL980_statistik.mean_film_thickness__mm,8900;...
                                   X100_ReG12900_ReL980_statistik.mean_film_thickness__mm,12900;...
                                   X100_ReG16900_ReL980_statistik.mean_film_thickness__mm,16900;...
                                   X100_ReG20900_ReL980_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL1100_X100_mean_film_thickness = [ X100_ReG0_ReL1100_statistik.mean_film_thickness__mm,0;...
                                   X100_ReG4900_ReL1100_statistik.mean_film_thickness__mm,4900;...
                                   X100_ReG8900_ReL1100_statistik.mean_film_thickness__mm,8900;...
                                   X100_ReG12900_ReL1100_statistik.mean_film_thickness__mm,12900;...
                                   X100_ReG16900_ReL1100_statistik.mean_film_thickness__mm,16900;...
                                   X100_ReG20900_ReL1100_statistik.mean_film_thickness__mm,20900];


figure(11)
e1=plot(ReGVar_ReL500_X100_mean_film_thickness(:,2),ReGVar_ReL500_X100_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','square',"Color",[0 0.4470 0.7410],"MarkerFaceColor",[0 0.4470 0.7410],"MarkerSize",8);
hold on
e2=plot(ReGVar_ReL620_X100_mean_film_thickness(:,2),ReGVar_ReL620_X100_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','diamond',"Color",[0.8500 0.3250 0.0980],"MarkerFaceColor",[0.8500 0.3250 0.0980],"MarkerSize",8);
hold on
e3=plot(ReGVar_ReL740_X100_mean_film_thickness(:,2),ReGVar_ReL740_X100_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','^',"Color",[0.4940 0.1840 0.5560],"MarkerFaceColor",[0.4940 0.1840 0.5560],"MarkerSize",8);
hold on
e4=plot(ReGVar_ReL860_X100_mean_film_thickness(:,2),ReGVar_ReL860_X100_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','v',"Color",[0.4660 0.6740 0.1880],"MarkerFaceColor",[0.4660 0.6740 0.1880],"MarkerSize",8);
hold on
e5=plot(ReGVar_ReL980_X100_mean_film_thickness(:,2),ReGVar_ReL980_X100_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','o',"Color",[0.6350 0.0780 0.1840],"MarkerFaceColor",[0.6350 0.0780 0.1840],"MarkerSize",8);
hold on
e6=plot(ReGVar_ReL1100_X100_mean_film_thickness(:,2),ReGVar_ReL1100_X100_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','pentagram',"Color",[0 0 0],"MarkerFaceColor",[0 0 0]);

ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
ax.YAxis.Exponent = -3; % Set exponent for scientific notation
xlabel('$Re_{gas} [-]$','interpreter','latex','FontSize',20)
ylabel('Average film height [m]','interpreter','latex','FontSize',20)
lgd2=legend([e6,e5,e4,e3,e2,e1],{'$Re_{liq} = 1,100$', '$Re_{liq} = 980$', '$Re_{liq} = 860$', '$Re_{liq} = 740$', '$Re_{liq} = 620$', '$Re_{liq} = 500$'}, 'Interpreter', 'latex','FontSize',18);
lgd2.Location= 'northoutside';
lgd2.Orientation= 'horizontal';
lgd2.NumColumns =3;
ax.XLim=[0,28000];

%% Einfluss von ReG Filmdicke bei X = 600

ReGVar_ReL500_X600_mean_film_thickness = [ X600_ReG0_ReL500_statistik.mean_film_thickness__mm,0;...
                                   X600_ReG4900_ReL500_statistik.mean_film_thickness__mm,4900;...
                                   X600_ReG8900_ReL500_statistik.mean_film_thickness__mm,8900;...
                                   X600_ReG12900_ReL500_statistik.mean_film_thickness__mm,12900;...
                                   X600_ReG16900_ReL500_statistik.mean_film_thickness__mm,16900;...
                                   X600_ReG20900_ReL500_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL620_X600_mean_film_thickness = [ X600_ReG0_ReL620_statistik.mean_film_thickness__mm,0;...
                                   X600_ReG4900_ReL620_statistik.mean_film_thickness__mm,4900;...
                                   X600_ReG8900_ReL620_statistik.mean_film_thickness__mm,8900;...
                                   X600_ReG12900_ReL620_statistik.mean_film_thickness__mm,12900;...
                                   X600_ReG16900_ReL620_statistik.mean_film_thickness__mm,16900;...
                                   X600_ReG20900_ReL620_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL740_X600_mean_film_thickness = [ X600_ReG0_ReL740_statistik.mean_film_thickness__mm,0;...
                                   X600_ReG4900_ReL740_statistik.mean_film_thickness__mm,4900;...
                                   X600_ReG8900_ReL740_statistik.mean_film_thickness__mm,8900;...
                                   X600_ReG12900_ReL740_statistik.mean_film_thickness__mm,12900;...
                                   X600_ReG16900_ReL740_statistik.mean_film_thickness__mm,16900;...
                                   X600_ReG20900_ReL740_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL860_X600_mean_film_thickness = [ X600_ReG0_ReL860_statistik.mean_film_thickness__mm,0;...
                                   X600_ReG4900_ReL860_statistik.mean_film_thickness__mm,4900;...
                                   X600_ReG8900_ReL860_statistik.mean_film_thickness__mm,8900;...
                                   X600_ReG12900_ReL860_statistik.mean_film_thickness__mm,12900;...
                                   X600_ReG16900_ReL860_statistik.mean_film_thickness__mm,16900;...
                                   X600_ReG20900_ReL860_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL980_X600_mean_film_thickness = [ X600_ReG0_ReL980_statistik.mean_film_thickness__mm,0;...
                                   X600_ReG4900_ReL980_statistik.mean_film_thickness__mm,4900;...
                                   X600_ReG8900_ReL980_statistik.mean_film_thickness__mm,8900;...
                                   X600_ReG12900_ReL980_statistik.mean_film_thickness__mm,12900;...
                                   X600_ReG16900_ReL980_statistik.mean_film_thickness__mm,16900;...
                                   X600_ReG20900_ReL980_statistik.mean_film_thickness__mm,20900];

ReGVar_ReL1100_X600_mean_film_thickness = [ X600_ReG0_ReL1100_statistik.mean_film_thickness__mm,0;...
                                   X600_ReG4900_ReL1100_statistik.mean_film_thickness__mm,4900;...
                                   X600_ReG8900_ReL1100_statistik.mean_film_thickness__mm,8900;...
                                   X600_ReG12900_ReL1100_statistik.mean_film_thickness__mm,12900;...
                                   X600_ReG16900_ReL1100_statistik.mean_film_thickness__mm,16900;...
                                   X600_ReG20900_ReL1100_statistik.mean_film_thickness__mm,20900];

figure(12)
k1=plot(ReGVar_ReL500_X600_mean_film_thickness(:,2),ReGVar_ReL500_X600_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','square',"Color",[0 0.4470 0.7410],"MarkerFaceColor",[0 0.4470 0.7410],"MarkerSize",8);
hold on
k2=plot(ReGVar_ReL620_X600_mean_film_thickness(:,2),ReGVar_ReL620_X600_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','diamond',"Color",[0.8500 0.3250 0.0980],"MarkerFaceColor",[0.8500 0.3250 0.0980],"MarkerSize",8);
hold on
k3=plot(ReGVar_ReL740_X600_mean_film_thickness(:,2),ReGVar_ReL740_X600_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','^',"Color",[0.4940 0.1840 0.5560],"MarkerFaceColor",[0.4940 0.1840 0.5560],"MarkerSize",8);
hold on
k4=plot(ReGVar_ReL860_X600_mean_film_thickness(:,2),ReGVar_ReL860_X600_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','v',"Color",[0.4660 0.6740 0.1880],"MarkerFaceColor",[0.4660 0.6740 0.1880],"MarkerSize",8);
hold on
k5=plot(ReGVar_ReL980_X600_mean_film_thickness(:,2),ReGVar_ReL980_X600_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','o',"Color",[0.6350 0.0780 0.1840],"MarkerFaceColor",[0.6350 0.0780 0.1840],"MarkerSize",8);
hold on
k6=plot(ReGVar_ReL1100_X600_mean_film_thickness(:,2),ReGVar_ReL1100_X600_mean_film_thickness(:,1)/1000,'LineStyle','none','Marker','pentagram',"Color",[0 0 0],"MarkerFaceColor",[0 0 0]);

ax = gca;
ax.FontSize = 18; 
ax.TickLabelInterpreter = "latex";
ax.YAxis.Exponent = -3; % Set exponent for scientific notation
xlabel('$Re_{gas} [-]$','interpreter','latex','FontSize',20)
ylabel('Average film height [m]','interpreter','latex','FontSize',20)
lgd3=legend([k6,k5,k4,k3,k2,k1],{'$Re_{liq} = 1,100$', '$Re_{liq} = 980$', '$Re_{liq} = 860$', '$Re_{liq} = 740$', '$Re_{liq} = 620$', '$Re_{liq} = 500$'}, 'Interpreter', 'latex','FontSize',18);
lgd3.Location= 'northoutside';
lgd3.Orientation= 'horizontal';
lgd3.NumColumns =3;

ax.XLim=[0,28000];

