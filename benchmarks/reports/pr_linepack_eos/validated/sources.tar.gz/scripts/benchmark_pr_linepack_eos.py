"""Paired CPU timings of identical linepack equations with grouped endpoint EOS."""

import argparse
import gzip
import hashlib
import json
import statistics
import tarfile
import time
from pathlib import Path

from check_pr_linepack import audit
from run_pr_linepack import run


def benchmark(config, output, repeats=2):
    from surface.stratified_pr_network import StratifiedNetworkState, StratifiedPRNetwork

    if type(repeats) is not int or repeats < 1:
        raise ValueError("Positive integer repeat count required")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[1]
    paths = sorted((root / "src/surface").glob("*.py")) + [
        Path(__file__).resolve(),
        root / "scripts/run_pr_linepack.py",
        root / "scripts/check_pr_linepack.py",
    ]
    hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (output / "request.json").write_text(json.dumps(config, indent=2) + "\n")
    with tarfile.open(output / "sources.tar.gz", "w:gz") as archive:
        for path in paths:
            archive.add(path, arcname=str(path.relative_to(root)))
    # Warm imports outside timings. No solver/flash warmup is removed from
    # measured runs: every sample constructs and initializes the entire model.
    from surface.pr_linepack import PRLinepackNetwork

    samples, comparisons = [], []
    previous = StratifiedPRNetwork._batch_connector_eos
    try:
        for repeat in range(repeats):
            results = {}
            methods = (False, True) if repeat % 2 == 0 else (True, False)
            for grouped in methods:
                method = "grouped" if grouped else "original"
                StratifiedPRNetwork._batch_connector_eos = grouped
                start = time.perf_counter()
                result = run(config, device="cpu")
                wall = time.perf_counter() - start
                result = json.loads(json.dumps(result, allow_nan=False))
                certificate = audit(config, result)
                if certificate.get("accepted") is not True:
                    raise ValueError("Independent linepack audit rejected")
                name = f"repeat-{repeat}-{method}.json.gz"
                with gzip.open(output / name, "wt") as stream:
                    json.dump(result, stream, allow_nan=False)
                row = {
                    "repeat": repeat,
                    "method": method,
                    "wall_s": wall,
                    "audit": certificate,
                    "trajectory": name,
                    "accepted_substeps": sum(len(i["steps"]) for i in result["intervals"]),
                }
                print(json.dumps(row), flush=True)
                samples.append(row)
                (output / "samples.json").write_text(json.dumps(samples, indent=2) + "\n")
                results[method] = result
            model = PRLinepackNetwork.from_dict(config["model"], device="cpu")
            differences = [
                model.network._error(
                    dict(StratifiedNetworkState.from_dict(a["state"]).vessels),
                    dict(StratifiedNetworkState.from_dict(b["state"]).vessels),
                )
                for a, b in zip(results["original"]["intervals"], results["grouped"]["intervals"])
            ]
            maximum = max(differences)
            if maximum > 1.0:
                raise ValueError("Grouped EOS changed trajectory beyond original temporal norm")
            comparisons.append(
                {"repeat": repeat, "maximum_interval_difference_in_original_norm": maximum}
            )
        for path in paths:
            if hashlib.sha256(path.read_bytes()).hexdigest() != hashes[str(path.relative_to(root))]:
                raise RuntimeError(f"Source changed during benchmark: {path}")
        medians = {
            method: statistics.median(row["wall_s"] for row in samples if row["method"] == method)
            for method in ("original", "grouped")
        }
        result = {
            "accepted": True,
            "device": "cpu",
            "repeats": repeats,
            "timing_scope": "construction, initialization and solve; excludes independent audit/serialization",
            "simulation_duration_s": sum(c["duration_s"] for c in config["schedule"]),
            "median_wall_s": medians,
            "speedup": medians["original"] / medians["grouped"],
            "samples": samples,
            "comparisons": comparisons,
            "source_sha256": hashes,
            "scope": "same equations, quadrature and tolerances; synthetic linepack only; no GPU/field qualification",
        }
        (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
        return result
    finally:
        StratifiedPRNetwork._batch_connector_eos = previous


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=2)
    args = parser.parse_args()
    print(
        json.dumps(
            benchmark(json.loads(args.config.read_text()), args.output, args.repeats), indent=2
        )
    )
