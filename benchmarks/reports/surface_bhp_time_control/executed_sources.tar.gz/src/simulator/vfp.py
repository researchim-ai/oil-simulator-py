"""
Таблицы лифта VFPPROD (Eclipse): забойное давление на опорной глубине таблицы как функция
дебита (FLO), устьевого давления (THP), обводнённости (WFR), газового фактора (GFR) и газлифта (ALQ).

Интерполяция многолинейная по пяти осям, за пределами осей — линейная экстраполяция крайним
интервалом (как в OPM, VFPHelpers). Всё в СИ: дебиты — ст. м³/с, давления — Па, отношения — м³/м³.
"""
import itertools

import torch

DAY = 86400.0


def _axis_weights(axis, x):
    """Индекс левого узла и доля внутри интервала (может выходить за [0, 1] — экстраполяция)."""
    n = axis.numel()
    if n == 1:
        # A constant axis still has a defined (zero) derivative. Retain the
        # graph so a constant lift table can participate in Newton assembly.
        return torch.zeros_like(x, dtype=torch.long), x * 0.0
    i = (torch.searchsorted(axis, x.detach().contiguous(), right=True) - 1).clamp(0, n - 2)
    x0, x1 = axis[i], axis[i + 1]
    return i, (x - x0) / (x1 - x0)


class _VFP:
    def _on(self, dev):
        """Оси (THP, WFR, GFR, ALQ, FLO) и таблица на устройстве dev — копия на устройство один раз."""
        cache = self.__dict__.setdefault("_dev", {})
        if dev not in cache:
            cache[dev] = ([a.to(dev) for a in (self.thp, self.wfr, self.gfr, self.alq, self.flo)], self.table.to(dev))
        return cache[dev]

    def thp_from_bhp(self, bhp, qo, qw, qg, alq=0.0):
        """Обратная задача: THP, при котором таблица даёт bhp (BHP линейна по THP на интервале оси)."""
        thp = self.thp.to(bhp.device)
        vals = torch.stack([self.bhp(qo, qw, qg, t, alq) for t in thp])          # [n_thp, ...]
        n = thp.numel()
        if n == 1:
            return thp[0].expand_as(bhp)
        k = ((vals <= bhp.unsqueeze(0)).sum(0) - 1).clamp(0, n - 2)
        b0 = vals.gather(0, k.unsqueeze(0)).squeeze(0)
        b1 = vals.gather(0, (k + 1).unsqueeze(0)).squeeze(0)
        t0, t1 = thp[k], thp[k + 1]
        return t0 + (bhp - b0) * (t1 - t0) / torch.where((b1 - b0).abs() > 0, b1 - b0, torch.ones_like(b0))


class VFPProd(_VFP):
    FLO = ("OIL", "LIQ", "GAS")
    WFR = ("WOR", "WCT", "WGR")
    GFR = ("GOR", "GLR", "OGR")

    def __init__(self, records, u, depth_shift=0.0):
        """records — записи ключевого слова VFPPROD; u — переводные множители deck → СИ (EclipseCase.u)."""
        head = records[0]
        g = lambda k, d=None: head[k] if len(head) > k and head[k] is not None else d
        self.number = int(head[0])
        self.datum = float(head[1]) * u["L"] - depth_shift
        self.flo_type = str(g(2, "OIL")).upper()
        self.wfr_type = str(g(3, "WCT")).upper()
        self.gfr_type = str(g(4, "GOR")).upper()
        thp_type = str(g(5, "THP")).upper()
        alq_type = str(g(6, "")).upper()
        tab_type = str(g(8, "BHP")).upper()
        if self.flo_type not in self.FLO or self.wfr_type not in self.WFR or self.gfr_type not in self.GFR:
            raise NotImplementedError(f"VFPPROD {self.number}: оси {self.flo_type}/{self.wfr_type}/{self.gfr_type}")
        if thp_type != "THP" or tab_type != "BHP":
            raise NotImplementedError(f"VFPPROD {self.number}: {thp_type}/{tab_type} (поддерживаются THP и BHP)")
        if alq_type not in ("", "GRAT", "IGLR", "TGLR", "PUMP", "COMP", "BEAN", "ALQ"):
            raise NotImplementedError(f"VFPPROD {self.number}: ALQ {alq_type}")
        p, liq, gas = u["p"], u["liq"] / DAY, u["gas"] / DAY
        flo_u = gas if self.flo_type == "GAS" else liq
        wfr_u = {"WOR": 1.0, "WCT": 1.0, "WGR": u["liq"] / u["gas"]}[self.wfr_type]
        gfr_u = {"GOR": u["gas"] / u["liq"], "GLR": u["gas"] / u["liq"], "OGR": u["liq"] / u["gas"]}[self.gfr_type]
        T = lambda rec, s: torch.tensor([float(v) * s for v in rec], dtype=torch.float64)
        self.flo, self.thp = T(records[1], flo_u), T(records[2], p)
        self.wfr, self.gfr, self.alq = T(records[3], wfr_u), T(records[4], gfr_u), T(records[5], 1.0)
        shape = (self.thp.numel(), self.wfr.numel(), self.gfr.numel(), self.alq.numel(), self.flo.numel())
        tab = torch.full(shape, float("nan"), dtype=torch.float64)
        for rec in records[6:]:
            if not rec:
                continue
            it, iw, ig, ia = (int(v) - 1 for v in rec[:4])
            tab[it, iw, ig, ia] = torch.tensor([float(v) * p for v in rec[4:4 + shape[4]]], dtype=torch.float64)
        if torch.isnan(tab).any():
            raise ValueError(f"VFPPROD {self.number}: таблица заполнена не полностью")
        self.table = tab

    def _ratios(self, qo, qw, qg):
        div = lambda a, b: torch.where(b.abs() > 1e-30, a / torch.where(b.abs() > 1e-30, b, torch.ones_like(b)),
                                       torch.zeros_like(a))
        flo = {"OIL": qo, "LIQ": qo + qw, "GAS": qg}[self.flo_type]
        wfr = {"WOR": div(qw, qo), "WCT": div(qw, qo + qw), "WGR": div(qw, qg)}[self.wfr_type]
        gfr = {"GOR": div(qg, qo), "GLR": div(qg, qo + qw), "OGR": div(qo, qg)}[self.gfr_type]
        return flo, wfr, gfr

    def bhp(self, qo, qw, qg, thp, alq=0.0):
        """BHP на опорной глубине таблицы, Па; дебиты добычи (> 0), ст. м³/с; тензоры одной формы."""
        dev = qo.device
        flo, wfr, gfr = self._ratios(qo, qw, qg)
        thp = torch.as_tensor(thp, dtype=torch.float64, device=dev).expand_as(flo)
        alq = torch.as_tensor(alq, dtype=torch.float64, device=dev).expand_as(flo)
        axes, tab = self._on(dev)
        idx, frac = zip(*(_axis_weights(a, x) for a, x in zip(axes, (thp, wfr, gfr, alq, flo))))
        # Batch the corners: network balancing calls this table repeatedly
        # during root searches. Avoid launching a tensor operation for every
        # axis of every corner. Singleton axes contribute just one corner.
        cache = self.__dict__.setdefault('_corner_cache', {})
        if dev not in cache:
            bits = torch.tensor(list(itertools.product(
                *((0, 1) if a.numel() > 1 else (0,) for a in axes))),
                dtype=torch.long, device=dev)
            strides = tab.contiguous().stride()  # offsets address reshape(-1)
            offsets = sum(bits[:, k] * strides[k] for k in range(5))
            cache[dev] = (bits.bool(), offsets, strides)
        bits, offsets, strides = cache[dev]
        shape = (-1,) + (1,) * flo.ndim
        weight = torch.ones((offsets.numel(),) + flo.shape, dtype=flo.dtype, device=dev)
        base = torch.zeros_like(flo, dtype=torch.long)
        for k in range(5):
            base = base + idx[k] * strides[k]
            weight = weight * torch.where(bits[:, k].reshape(shape), frac[k], 1.0 - frac[k])
        values = tab.reshape(-1)[base.unsqueeze(0) + offsets.reshape(shape)]
        return (weight * values).sum(0)


class VFPInj(_VFP):
    """Таблица VFPINJ: BHP(FLO, THP), FLO — дебит закачиваемой фазы (> 0), ст. м³/с."""
    FLO = ("OIL", "WAT", "GAS")

    def __init__(self, records, u, depth_shift=0.0):
        head = records[0]
        self.number = int(head[0])
        self.datum = float(head[1]) * u["L"] - depth_shift
        self.flo_type = str(head[2] if len(head) > 2 and head[2] is not None else "WAT").upper()
        tab_type = str(head[5] if len(head) > 5 and head[5] is not None else "BHP").upper()
        if self.flo_type not in self.FLO:
            raise NotImplementedError(f"VFPINJ {self.number}: FLO {self.flo_type}")
        if tab_type != "BHP":
            raise NotImplementedError(f"VFPINJ {self.number}: {tab_type} (поддерживается BHP)")
        p = u["p"]
        flo_u = (u["gas"] if self.flo_type == "GAS" else u["liq"]) / DAY
        T = lambda rec, s: torch.tensor([float(v) * s for v in rec], dtype=torch.float64)
        self.flo, self.thp = T(records[1], flo_u), T(records[2], p)
        tab = torch.full((self.thp.numel(), self.flo.numel()), float("nan"), dtype=torch.float64)
        for rec in records[3:]:
            if rec:
                tab[int(rec[0]) - 1] = torch.tensor([float(v) * p for v in rec[1:1 + self.flo.numel()]],
                                                    dtype=torch.float64)
        if torch.isnan(tab).any():
            raise ValueError(f"VFPINJ {self.number}: таблица заполнена не полностью")
        self.table = tab

    def bhp(self, qo, qw, qg, thp, alq=0.0):
        """BHP на опорной глубине таблицы, Па; дебиты закачки (> 0), ст. м³/с."""
        dev = qo.device
        flo = {"OIL": qo, "WAT": qw, "GAS": qg}[self.flo_type]
        thp = torch.as_tensor(thp, dtype=torch.float64, device=dev).expand_as(flo)
        axes = [self.thp.to(dev), self.flo.to(dev)]
        (it, ft), (iq, fq) = (_axis_weights(a, x) for a, x in zip(axes, (thp, flo)))
        tab = self.table.to(dev)
        out = torch.zeros_like(flo)
        for ct in (0, 1):
            if ct and axes[0].numel() == 1:
                continue
            wt = ft if ct else 1.0 - ft
            for cq in (0, 1):
                if cq and axes[1].numel() == 1:
                    continue
                out = out + wt * (fq if cq else 1.0 - fq) * tab[it + ct, iq + cq]
        return out
