"""Run frozen immiscible thermal three-phase separator trains on Torch CPU/CUDA."""

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from surface import ThreePhaseSeparatorNetwork, run_three_phase_schedule


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device")
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--stop-after", type=int)
    args = parser.parse_args()
    temporary = None
    try:
        data = json.loads(args.config.read_text())
        if set(data) != {"system", "initial", "periods"}:
            raise ValueError("Config requires exactly system, initial, periods")
        if args.device is not None:
            data["system"]["device"] = args.device
        model = ThreePhaseSeparatorNetwork.from_dict(data["system"])
        initial = model.initialize(**data["initial"])
        result = run_three_phase_schedule(
            model,
            initial,
            data["periods"],
            json.loads(args.checkpoint.read_text()) if args.checkpoint else None,
            args.stop_after,
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            mode="w",
            dir=args.output.parent,
            delete=False,
            prefix="." + args.output.name,
            suffix=".tmp",
        ) as output:
            temporary = Path(output.name)
            json.dump(result, output, indent=2, allow_nan=False)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, args.output)
        temporary = None
    except (ValueError, TypeError, KeyError, RuntimeError, OSError) as error:
        parser.exit(2, f"{error}\n")
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
