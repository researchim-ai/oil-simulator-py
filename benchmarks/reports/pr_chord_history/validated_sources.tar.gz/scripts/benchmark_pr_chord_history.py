"""Paired whole-schedule qualification of guarded Radau chord history.

Fresh physical initial conditions, one shared native context, alternating
policies. Compilation and independent audits are outside warm measurements.
No different time tolerances, geometry or thermodynamic shortcuts.
"""

import argparse
import gzip
import hashlib
import json
import statistics
from pathlib import Path

from benchmark_pr_fast_integrator import measure
from check_pr_controlled_surface import audit

from surface.equilibrium_properties import EquilibriumFluid
from surface.native_execution import native_kernel_execution
from surface.pr_collocation import PRCollocation
from surface.pr_surface_control import PRControlledSurface, PRControlledSurfaceState
from surface.torch_backend import runtime_fingerprint
from surface.torch_nonlinear import TorchNewton


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("Positive repeat count required")
    request = json.loads(args.config.read_text())
    args.output_dir.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[1]
    paths = [
        *sorted((root / "src/surface").glob("*.py")),
        Path(__file__),
        root / "scripts/benchmark_pr_fast_integrator.py",
        root / "scripts/run_pr_controlled_surface.py",
        root / "scripts/check_pr_controlled_surface.py",
    ]
    hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (args.output_dir / "request.json").write_text(json.dumps(request, indent=2) + "\n")
    (args.output_dir / "manifest.json").write_text(json.dumps(hashes, indent=2) + "\n")
    EquilibriumFluid._compiled_chemical_cpu = True
    EquilibriumFluid._compiled_full_eos_cpu = True
    TorchNewton._dense_jacobian_mode = "reverse"
    model = PRControlledSurface.from_dict(request["model"])
    results = {"fresh_solve": [], "guarded_history": []}
    endpoints = {}

    def execute(label, repeat):
        PRCollocation._reuse_step_jacobian = label == "guarded_history"
        report, record = measure(
            request, native=True, progress=lambda e: print(json.dumps(e), flush=True)
        )
        with gzip.open(args.output_dir / f"{label}_{repeat}.json.gz", "wt") as handle:
            json.dump({"request": request, "report": report, **record}, handle, allow_nan=False)
        checked = audit(request, report)
        if checked.get("accepted") is not True:
            raise ValueError("Independent physical audit rejected trajectory")
        endpoints[label] = [
            PRControlledSurfaceState.from_dict(v["state"]) for v in report["intervals"]
        ]
        counters = {key: 0 for key in ("hits", "refreshes", "builds")}
        linear_work = {key: 0 for key in ("jacobian_builds", "jacobian_reuses")}
        for interval in report["intervals"]:
            for step in interval["steps"]:
                for stage in step["local_subcycling"]["stages"]:
                    if stage["operator"] == "fast":
                        for key, value in (
                            stage["report"].get("cross_step_linearization", {}).items()
                        ):
                            counters[key] += value
                        for key, value in stage["report"].get("linear_work", {}).items():
                            linear_work[key] += value
        record.update(
            audit=checked, policy=label, repeat=repeat, history=counters, linear_work=linear_work
        )
        print(json.dumps({"event": "completed", **record}), flush=True)
        return record

    old = PRCollocation._reuse_step_jacobian
    differences = []
    try:
        with native_kernel_execution(maximum_kernels=16) as engine:
            preparation = execute("fresh_solve", "preparation")
            settling = execute("guarded_history", "settling")
            for repeat in range(args.repeats):
                order = tuple(results) if repeat % 2 == 0 else tuple(reversed(results))
                for label in order:
                    results[label].append(execute(label, repeat))
                differences.append(
                    [
                        model._error(a, b)
                        for a, b in zip(
                            endpoints["fresh_solve"], endpoints["guarded_history"], strict=True
                        )
                    ]
                )
            execution = engine.statistics()
    finally:
        PRCollocation._reuse_step_jacobian = old
    unchanged = all(
        hashlib.sha256(p.read_bytes()).hexdigest() == hashes[str(p.relative_to(root))]
        for p in paths
    )
    medians = {k: statistics.median(v["wall_s"] for v in rows) for k, rows in results.items()}
    summary = {
        "scope": __doc__,
        "runtime": runtime_fingerprint(),
        "preparation": preparation,
        "settling": settling,
        "results": results,
        "warm_median_wall_s": medians,
        "observed_speedup": medians["fresh_solve"] / medians["guarded_history"],
        "difference_at_each_report_in_original_error_norm": differences,
        "independent_audits_passed": True,
        "sources_unchanged": unchanged,
        "native_execution": execution,
        "full_operating_cycle_qualified": False,
        "accepted": unchanged
        and max(map(max, differences)) <= 0.01
        and not execution["disabled"]
        and execution["fallback_calls"] == 0,
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=2))
    return 0 if summary["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
